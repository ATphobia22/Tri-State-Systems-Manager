                         CHECK-RAS Program, XS Check
                 Cross Section Location and Alignment Review


Project File:   J:\7041\Civil\Regulatory\IDNR\Construction in Floodway Submittal - Rail Loop\011309 Response to Division of Water\HecRas\ABENGOA_UNT_JMK.prj
Plan File:      J:\7041\Civil\Regulatory\IDNR\Construction in Floodway Submittal - Rail Loop\011309 Response to Division of Water\HecRas\ABENGOA_UNT_JMK.p02
Geometry File:  J:\7041\Civil\Regulatory\IDNR\Construction in Floodway Submittal - Rail Loop\011309 Response to Division of Water\HecRas\ABENGOA_UNT_JMK.g02
Flow File:      J:\7041\Civil\Regulatory\IDNR\Construction in Floodway Submittal - Rail Loop\011309 Response to Division of Water\HecRas\ABENGOA_UNT_JMK.f01
Report File:    J:\7041\Civil\Regulatory\IDNR\Construction in Floodway Submittal - Rail Loop\011309 Response to Division of Water\HecRas\ABENGOA_UNT_JMK.xs
Selected profiles: 100Yr
Date: 2/9/2009 
Time: 2:40:32 PM 


SECNO    Len Lob   Len Chl   Len Rob   TopWdthAct     Q Total   Flow Code
---------------------------------------------------------------------------
UNT Ohio River,West Upper UNT
1.355     260       280       294       37.63          470      
1.302     156.37    161.96    168.95    34.39          470      
1.271     227.05    235.78    208.6     28.7           470      
1.227     173.02    197.52    241.95    72.85          495      
1.189     156.65    174.78    174.95    102.21         495      
1.156     225.64    213.84    207.96    173.23         495      
1.116     103.27    107.87    111.17    215.36         495      
1.095     129.44    133.53    132.43    26.1           495      
1.083    DarnellCMPA-Up
1.083    DarnellCMPA-Dn
1.07      88.16     80.96     76.7      44.53          495      
1.055     255.8     249.94    245.05    21.07          495      
1.007     202       202       202       23.56          525      
.955      87        87        87        31.83          525      
.953      108       108       108       31.35          525      
.951      297       318       330       30.7           525      
.892      216.01    228.32    249.1     30.29          525      
.849      432.27    449.13    417.33    39.48          525      
.764      240       226       156       109.17         525      E
UNT Ohio River,East Upper UNT
1.006     45.5      47        50        224            529      
.997166*  45.5      47        50        221.62         529      
.988333*  45.5      47        50        223.46         529      
.9795*    45.5      47        50        224.58         529      
.970666*  45.5      47        50        226.9          529      
.961833*  45.5      47        50        251.29         529      
.953      0.8       1         1.38      264.36         529      
.95282*   0.8       1         1.38      265.07         529      
.95264*   0.8       1         1.38      263.06         529      
.95246*   0.8       1         1.38      264.1          529      
.95228*   0.8       1         1.38      264.99         529      
.9521*    0.8       1         1.38      264.81         529      
.95192*   0.8       1         1.38      265.63         529      
.95174*   0.8       1         1.38      264.78         529      
.95156*   0.8       1         1.38      264.98         529      
.95138*   0.8       1         1.38      265.01         529      
.9512*    0.8       1         1.38      264.54         529      
.95102*   0.8       1         1.38      264.79         529      
.95084*   0.8       1         1.38      264.85         529      
.95066*   0.8       1         1.38      265.13         529      
.95048*   0.8       1         1.38      264.91         529      
.9503*    0.8       1         1.38      265.58         529      
.95012*   0.8       1         1.38      264.83         529      
.94994*   0.8       1         1.38      264.95         529      
.94976*   0.8       1         1.38      265.22         529      
.94958*   0.8       1         1.38      265.16         529      
.9494*    0.8       1         1.38      266.12         529      
.94922*   0.8       1         1.38      262.38         529      D
.94904*   0.8       1         1.38      264.43         529      D
.94886*   0.8       1         1.38      265.45         529      
.94868*   0.8       1         1.38      261.52         529      D
.9485*    0.8       1         1.38      263.94         529      D
.94832*   0.8       1         1.38      258.29         529      D
.94814*   0.8       1         1.38      259.35         529      D
.94796*   0.8       1         1.38      260.42         529      D
.94778*   0.8       1         1.38      257.43         529      D
.9476*    0.8       1         1.38      256.88         529      D
.94742*   0.8       1         1.38      255.24         529      D
.94724*   0.8       1         1.38      254.89         529      D
.94706*   0.8       1         1.38      253.35         529      D
.94688*   0.8       1         1.38      250.18         529      D
.9467*    0.8       1         1.38      251.78         529      D
.94652*   0.8       1         1.38      250.92         529      D
.94634*   0.8       1         1.38      250.33         529      D
.94616*   0.8       1         1.38      247.17         529      D
.94598*   0.8       1         1.38      246.06         529      D
.9458*    0.8       1         1.38      243.66         529      D
.94562*   0.8       1         1.38      241.53         529      D
.94544*   0.8       1         1.38      242.25         529      D
.94526*   0.8       1         1.38      236.68         529      D
.94508*   0.8       1         1.38      231.69         529      D
.9449*    0.8       1         1.38      232.26         529      D
.94472*   0.8       1         1.38      226.05         529      D
.94454*   0.8       1         1.38      225.75         529      D
.94436*   0.8       1         1.38      222.67         529      D
.94418*   0.8       1         1.38      215.98         529      D
.944*     0.8       1         1.38      218.29         529      D
.94382*   0.8       1         1.38      213.79         529      D
.94364*   0.8       1         1.38      214.84         529      D
.94346*   0.8       1         1.38      211.35         529      D
.94328*   0.8       1         1.38      208.43         529      D
.9431*    0.8       1         1.38      208.84         529      D
.94292*   0.8       1         1.38      203.72         529      D
.94274*   0.8       1         1.38      204.81         529      D
.94256*   0.8       1         1.38      203.96         529      D
.94238*   0.8       1         1.38      203.56         529      D
.9422*    0.8       1         1.38      204.44         529      D
.94202*   0.8       1         1.38      202.15         529      D
.94184*   0.8       1         1.38      202.9          529      D
.94166*   0.8       1         1.38      202.25         529      D
.94148*   0.8       1         1.38      201.68         529      D
.9413*    0.8       1         1.38      202.42         529      D
.94112*   0.8       1         1.38      203.37         529      D
.94094*   0.8       1         1.38      204.21         529      D
.94076*   0.8       1         1.38      205.45         529      D
.94058*   0.8       1         1.38      206.71         529      D
.9404*    0.8       1         1.38      206.81         529      D
.94022*   0.8       1         1.38      207.25         529      D
.94004*   0.8       1         1.38      207.28         529      D
.93986*   0.8       1         1.38      208.42         529      D
.93968*   0.8       1         1.38      209.03         529      D
.9395*    0.8       1         1.38      210.31         529      D
.93932*   0.8       1         1.38      211.15         529      D
.93914*   0.8       1         1.38      211.8          529      D
.93896*   0.8       1         1.38      212.73         529      D
.93878*   0.8       1         1.38      213.44         529      D
.9386*    0.8       1         1.38      213.99         529      D
.93842*   0.8       1         1.38      214.93         529      D
.93824*   0.8       1         1.38      215.71         529      D
.93806*   0.8       1         1.38      216.52         529      D
.93788*   0.8       1         1.38      217.39         529      D
.9377*    0.8       1         1.38      217.99         529      D
.93752*   0.8       1         1.38      218.74         529      D
.93734*   0.8       1         1.38      219.37         529      D
.93716*   0.8       1         1.38      219.78         529      D
.93698*   0.8       1         1.38      220.58         529      D
.9368*    0.8       1         1.38      221.12         529      D
.93662*   0.8       1         1.38      222.37         529      D
.93644*   0.8       1         1.38      223.45         529      D
.93626*   0.8       1         1.38      224.13         529      D
.93608*   0.8       1         1.38      225.24         529      D
.9359*    0.8       1         1.38      226.28         529      D
.93572*   0.8       1         1.38      226.86         529      D
.93554*   0.8       1         1.38      227.87         529      D
.93536*   0.8       1         1.38      229.08         529      D
.93518*   0.8       1         1.38      229.66         529      D
.935      41        41        41        230.08         529      D
.927      142       142       142       192.03         529      D
.917     Culvert #1-Up
.917     Culvert #1-Dn
.899      50        50        50        206.7          529      
.889      167       218       228       62.48          529      D
.849      416.7     424.4     401       17.12          529      
.764      220       228       191       132.54         529      E
UNT Ohio River,Lower Main UNT
.69       217.12    221.8     225.59    196.99         1150     
.65       91        91        91        311.67         1150     
.62       200       200       200       223.76         1150     
.6        173.32    185.65    191.78    215.1          1150     
.56*      173.32    185.65    191.78    443.43         1150     
.52       94        116       116       409.58         1150     
.5        94        116       116       380.27         1150     
.48       330       313.68    330       418            1150     
.42       300       279.49    300       358.55         1150     
.37       250       270.45    270       112.31         1150     
.32*      250       270.45    270       24.48          1150     
.27       800       783.84    800       79.01          1150     B
.12       400       359.93    400       55.27          1150     B
.05       270       261       270       46.17          1150     B
0         0         0         0         37.1           1150     
---------------------------------------------------------------------------
B=blocked obstruction      XS SC 05
C=critial depth            XS SC 03
D=divided flow             XS SC 01
E=cross section extended   XS SC 02
K=known water-surface      XS SC 04



DISTANCE CHECK
----------------
XS JT 01 Junction option is used.
         For flood insurance study, this option should be used
         if the tributary and main stream can have coincident peaks,
         or it may be used for the stream without floodway. 
         It may also be used if the discharges at different time periods
         are known from the rainfall-runoff model.
         How to remove the junction is explained under Help.

XS JT 03 The name of junction is : J1
         The reach length at the most downstream cross section for the
         'UNT Ohio River and West Upper UNT' is not equal to zero.
         Please set the reach length equal to zero if juction can be considered.

XS JT 03 The name of junction is : J1
         The reach length at the most downstream cross section for the
         'UNT Ohio River and East Upper UNT' is not equal to zero.
         Please set the reach length equal to zero if juction can be considered.


SPACING CHECK
--------------

XS SP 02 This is an interpolated cross section.
         Interpolation of the cross sections should be performed only
         when all of the following conditions are met.
         Change in velocity head > 0.5
         Conveyance Ratio < 0.7 or Conveyance Ratio > 1.4
         Hydraulic Depth Ratio < 0.9 or Hydraulic Depth Ratio > 1.1
         Top Wdth Act Ratio < 0.5 or Top Wdth Act Ratio > 2.0
         Length Chnl Up / 500 > 1.1
         Please review the file with no interpolation and select the
         cross sections that meet the above criteria to consider
         interpolation.
         The following is the list of interpolated cross section:
              UNT Ohio River,East Upper UNT
                    0.997166 
                    0.988333 
                    0.9795 
                    0.970666 
                    0.961833 
                    0.95282 
                    0.95264 
                    0.95246 
                    0.95228 
                    0.9521 
                    0.95192 
                    0.95174 
                    0.95156 
                    0.95138 
                    0.9512 
                    0.95102 
                    0.95084 
                    0.95066 
                    0.95048 
                    0.9503 
                    0.95012 
                    0.94994 
                    0.94976 
                    0.94958 
                    0.9494 
                    0.94922 
                    0.94904 
                    0.94886 
                    0.94868 
                    0.9485 
                    0.94832 
                    0.94814 
                    0.94796 
                    0.94778 
                    0.9476 
                    0.94742 
                    0.94724 
                    0.94706 
                    0.94688 
                    0.9467 
                    0.94652 
                    0.94634 
                    0.94616 
                    0.94598 
                    0.9458 
                    0.94562 
                    0.94544 
                    0.94526 
                    0.94508 
                    0.9449 
                    0.94472 
                    0.94454 
                    0.94436 
                    0.94418 
                    0.944 
                    0.94382 
                    0.94364 
                    0.94346 
                    0.94328 
                    0.9431 
                    0.94292 
                    0.94274 
                    0.94256 
                    0.94238 
                    0.9422 
                    0.94202 
                    0.94184 
                    0.94166 
                    0.94148 
                    0.9413 
                    0.94112 
                    0.94094 
                    0.94076 
                    0.94058 
                    0.9404 
                    0.94022 
                    0.94004 
                    0.93986 
                    0.93968 
                    0.9395 
                    0.93932 
                    0.93914 
                    0.93896 
                    0.93878 
                    0.9386 
                    0.93842 
                    0.93824 
                    0.93806 
                    0.93788 
                    0.9377 
                    0.93752 
                    0.93734 
                    0.93716 
                    0.93698 
                    0.9368 
                    0.93662 
                    0.93644 
                    0.93626 
                    0.93608 
                    0.9359 
                    0.93572 
                    0.93554 
                    0.93536 
                    0.93518 
              UNT Ohio River,Lower Main UNT
                    0.56 
                    0.32 


INEFFECTIVE FLOW CHECK
-----------------------


DISCHARGE CHECK
----------------

XS DC 02 Constant dicharge used for the UNT Ohio River,East Upper UNT

XS DC 02 Constant dicharge used for the UNT Ohio River,Lower Main UNT


LOCATION CHECK
---------------


BOUNDARY CONDITION CHECK
------------------------

XS BC 02 The name of the stream is UNT Ohio River,Lower Main UNT
         Known WS = 349.7 is specified as the downstream boundary
         for profile 100Yr

XS BC 03 Maximum number of iterations is 0
         It should not be less than 20.


LATERAL WEIRS CHECK
-----------------------

---END---
